package pacman.graphics.tiles;

import pacman.graphics.Map;

/**
 *
 * @author Bren
 */
public class GateTile extends Tile {

    public GateTile(int id) {
        super(Map.gateTexture,id,0,0);
    }
    
}
