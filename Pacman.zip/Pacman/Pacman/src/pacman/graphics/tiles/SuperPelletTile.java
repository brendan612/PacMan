package pacman.graphics.tiles;

import pacman.graphics.Map;

/**
 *
 * @author Bren
 */
public class SuperPelletTile extends Tile {

    public SuperPelletTile(int id) {
        super(Map.superPelletTexture,id,0,0);
    }

    
}
