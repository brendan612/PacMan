package pacman.graphics;

public interface GraphicsPart {
    public abstract void tick(GraphicsLoop gl);
}
