
package pacman.entities.ghostHelp;

import java.awt.Point;

public class GhostMovements {
	public static void blinky(Point p){
		
	}
	public static void inky(Point p){
		
	}
	public static void pinky(Point p){
		
	}
	public static void clyde(Point p){
		
	}
}
