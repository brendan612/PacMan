package pacman.entities.ghostHelp;

/**
 *
 * @author David
 */
public enum GhostNames {
	Inky,
	Blinky,
	Pinky,
	Clyde
}
